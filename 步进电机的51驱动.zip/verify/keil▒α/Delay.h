#ifndef __DELAY_H__
#define __DELAY_H__
 
void Delay(unsigned int t);
 void Delay_ms(unsigned int n);
#endif