#include <reg51.h>
#include "Delay.h"

sbit KEY_1 = P2^0;
sbit KEY_2 = P2^1;
sbit KEY_3 = P2^2;
sbit KEY_4 = P2^3;

unsigned char key() {
    unsigned char KeyNumber = 0;  // �������KeyNumber����ʼ��Ϊ0
    if(KEY_1==0){Delay(20);while(KEY_1==0);Delay(20);KeyNumber = 1;}
	if(KEY_2==0){Delay(20);while(KEY_2==0);Delay(20);KeyNumber = 2;}
	if(KEY_3==0){Delay(20);while(KEY_3==0);Delay(20);KeyNumber = 3;}
    return  KeyNumber;
    }      