#include <reg51.h>
#include <stdio.h>
#include <intrins.h>
 
#define uint	unsigned int
#define uchar	unsigned char

unsigned char code z[]={0x02,0x06,0x04,0x0c,0x08,0x09,0x01,0x03//315,270,225......360(0)
};//����
unsigned char code f[]={0x01,0x09,0x08,0x0c,0x04,0x06,0x02,0x03//45,90,145......360(0)
};
sbit Button1 = P3^0;//���尴���˿�
sbit Button2 = P3^1;
sbit Button3 = P3^2;
void bujin();

sbit EOC = P2^6;
sbit ST = P2^5;
sbit OE = P2^7;
sbit CLK = P2^4;


unsigned char adjoin;
void DelayMS( uint ms )
{
	uchar i;
	while ( ms-- )
	{
		for ( i = 0; i < 120; i++ )
			;
	}
}
void A_Dchange()//ģ��ת���ĺ���
{
   OE = 0;
   ST = 0;
   ST = 1;
   ST = 0;
   DelayMS(1);
   while(!EOC);
      OE = 1;
   adjoin = P0;
   OE = 0;
}

void clockwise(unsigned char n)//��ת
{
 	unsigned char i,j;
	for(i=0;i<n;i++)
	{
	 	for(j=0;j<8;j++)
		{
		 if(Button3 == 0||Button2==0) break;
			P1 = z[j];
			A_Dchange();
			DelayMS(adjoin);
		
		}
	}
}
void counterclockwise(unsigned char n)//��ת
{
 	unsigned char i,j;
	for(i=0;i<n;i++)
	{
	 	for(j=0;j<8;j++)
		{
		 
			if(Button3 == 0||Button1==0) break;
			P1 = f[j];
			A_Dchange();
			DelayMS(adjoin);
		
		}
	}
}

void t0() interrupt 1 using 0
{
    CLK = ~CLK;
}
void main()
{
	unsigned char N = 1;//�˴��趨Ȧ����
    EA = 1;
    TMOD=0x02;//���ö�ʱ��ģʽ
    TH0 = 216;//ע���ֵ
    TL0 = 216;
    TR0 = 1;
    ET0 = 1;   
	
	while(1)
	{
	    A_Dchange();
	 	if(Button1 == 0)
		{
			while(1)
			{
				P2 = 0xfe;
				clockwise(N);
				if(Button3 == 0||Button2==0) break;
			}
		}
		else if(Button2 == 0)
		{
			while(1)
			{
				P2 = 0xfd;
				counterclockwise(N);
				if(Button3 == 0||Button1==0) break;
			}
		}
		else
		{
			P2 = 0xfb;
			P1 = 0x03;
		}
	}
}

 